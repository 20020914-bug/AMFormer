"""Only the GBDT teacher components used by the published GeoMPF experiment."""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier

LABELS = [0, 1, 2, 3]
FIXED_TEST_WELLS = {"磨溪109", "磨溪52", "磨溪110", "高石10", "高石121", "高石123"}


def make_model() -> GradientBoostingClassifier:
    return GradientBoostingClassifier(
        loss="log_loss",
        n_estimators=160,
        learning_rate=0.05,
        max_depth=3,
        min_samples_leaf=15,
        subsample=0.8,
        random_state=42,
    )


def sample_weight(y: pd.Series) -> np.ndarray:
    """Match the teacher weighting used in the completed experiment."""
    counts = y.value_counts().to_dict()
    balanced = {label: len(y) / (len(LABELS) * count) for label, count in counts.items()}
    priority = {0: 1.0, 1: 2.2, 2: 2.0, 3: 1.7}
    return y.map({label: weight * priority[label] for label, weight in balanced.items()}).to_numpy()
