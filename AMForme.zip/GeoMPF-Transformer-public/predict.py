"""Apply a trained GeoMPF-Transformer and its fitted GBDT prior to unlabeled wells."""

from __future__ import annotations

import argparse
import json
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import torch
from pandas.errors import PerformanceWarning

from features import build_features, load_curve_csvs, read_layer_intervals
from train import (LocalGeologyTransformer, RAW_COLUMNS, WINDOW, STRIDE,
                   predict_well, remove_thin_reservoir_segments)


def main(input_dir: Path, layer_file: Path, checkpoint: Path,
         prior_file: Path, output_dir: Path) -> None:
    warnings.filterwarnings("ignore", category=PerformanceWarning)
    # Serialized model files should come from a source the user trusts.
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    teacher = joblib.load(prior_file)
    if payload["window"] != WINDOW or payload["stride"] != STRIDE:
        raise ValueError("Checkpoint window/stride does not match this code")
    if payload["raw_columns"] != RAW_COLUMNS:
        raise ValueError("Checkpoint raw curve order does not match this code")
    raw = load_curve_csvs(input_dir, require_label=False)
    intervals = read_layer_intervals(layer_file, set(raw["井名"]))
    features, generated_columns = build_features(raw, intervals)
    teacher_columns = list(payload.get("teacher_feature_columns",
                                       getattr(teacher, "feature_names_in_", [])))
    selected = list(payload["feature_columns"])
    if not teacher_columns or not set(teacher_columns) <= set(generated_columns):
        raise ValueError("The engineered teacher features do not match the checkpoint")
    if not set(selected) <= set(generated_columns):
        raise ValueError("The selected Transformer features do not match the checkpoint")
    if len(selected) != 48 or not set(RAW_COLUMNS) <= set(selected):
        raise ValueError("The checkpoint's selected feature set is invalid")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = LocalGeologyTransformer(len(selected)).to(device)
    model.load_state_dict(payload["state_dict"])
    model.eval()
    mean = np.asarray(payload["feature_mean"], dtype=np.float32)
    std = np.asarray(payload["feature_std"], dtype=np.float32)
    raw_mean = np.asarray(payload["raw_mean"], dtype=np.float32)
    raw_std = np.asarray(payload["raw_std"], dtype=np.float32)
    if mean.shape != (len(selected),) or std.shape != mean.shape:
        raise ValueError("Transformer normalization shape does not match features")
    if raw_mean.shape != (len(RAW_COLUMNS),) or raw_std.shape != raw_mean.shape:
        raise ValueError("Raw normalization shape does not match curves")
    if np.any(std == 0) or np.any(raw_std == 0):
        raise ValueError("Zero normalization standard deviation in checkpoint")
    prior_weight = float(payload["prior_weight"])
    if not 0 <= prior_weight <= 1:
        raise ValueError("Invalid prior weight")
    if not np.array_equal(np.sort(teacher.classes_.astype(int)), np.arange(4)):
        raise ValueError("The teacher must provide probabilities for Types 0–3")

    output_dir.mkdir(parents=True, exist_ok=True)
    records = []
    for well, part in features.groupby("井名", sort=True):
        source = part.sort_values("Depth").reset_index(drop=True)
        depth = source["Depth"].to_numpy(float)
        if len(depth) == 0 or np.any(~np.isfinite(depth)) or np.any(np.diff(depth) <= 0):
            raise ValueError(f"Depth is not strictly increasing in well {well}")
        teacher_compact = teacher.predict_proba(source[teacher_columns])
        teacher_prob = np.zeros((len(source), 4), dtype=np.float32)
        teacher_prob[:, teacher.classes_.astype(int)] = teacher_compact
        item = {
            "labels": np.zeros(len(source), dtype=np.int64),  # length only; never evaluated
            "features": ((source[selected].to_numpy(np.float32) - mean) / std),
            "raw": ((source[RAW_COLUMNS].to_numpy(np.float32) - raw_mean) / raw_std),
        }
        if not np.isfinite(item["features"]).all() or not np.isfinite(item["raw"]).all():
            raise ValueError(f"Nonfinite features in well {well}")
        student_prob = predict_well(model, item, device)
        probability = (1 - prior_weight) * student_prob + prior_weight * teacher_prob
        raw_class = probability.argmax(axis=1)
        final_class = remove_thin_reservoir_segments(raw_class, depth)
        output = source[["井名", "Depth"]].copy()
        for label in range(4):
            output[f"Type_{label}_probability"] = probability[:, label]
        output["Predicted_before_sequence_constraint"] = raw_class
        output["Predicted_type"] = final_class
        output.to_csv(output_dir / f"{well}_predictions.csv", index=False, encoding="utf-8-sig")
        records.append({"well": well, "samples": len(source),
                        "depth_min": float(depth[0]), "depth_max": float(depth[-1])})
    (output_dir / "prediction_manifest.json").write_text(
        json.dumps({"wells": records, "prior_weight": prior_weight,
                    "sequence_constraints": "bridge same-type gaps <=0.25 m, then map reservoir segments <1.0 m to Type 0"},
                   ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Wrote predictions for {len(records)} wells to {output_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", required=True, type=Path)
    parser.add_argument("--layer-file", required=True, type=Path)
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--prior-file", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    main(args.input_dir, args.layer_file, args.checkpoint,
         args.prior_file, args.output_dir)
