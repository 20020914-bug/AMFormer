"""Local-window geology-aware Transformer for four-class reservoir typing.

The independent test wells are never used for model or epoch selection.
The Transformer is fused with a validation-calibrated unconstrained GBDT soft
prior. Inference uses no curve-value threshold or class-forcing rule. Equal
reservoir types across an internal gap no thicker than 0.25 m are connected
before predicted reservoir segments thinner than 1.0 m are removed.
"""

from __future__ import annotations

import json
import argparse
import math
import random
import warnings
from copy import deepcopy
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import joblib
from pandas.errors import PerformanceWarning
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    precision_recall_fscore_support,
)
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader, Dataset

from plotting import curve_panels_v3, save_all
from features import build_features, load_curve_csvs, read_layer_intervals
from teacher import (
    FIXED_TEST_WELLS,
    LABELS,
    make_model,
    sample_weight,
)


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
RAW_COLUMNS = ["AC", "CNL", "DEN", "GR", "log_RT", "log_RXO"]
VALIDATION_WELLS = {"磨溪117", "高石135"}
WINDOW = 128
STRIDE = 48
FEATURE_COUNT = 48
MAX_EPOCHS = 120
PATIENCE = 24
MINIMUM_RESERVOIR_THICKNESS_M = 1.0
MAXIMUM_INTERNAL_GAP_M = 0.25
BASELINE = {
    # Published reference from the completed experiment; this baseline is not
    # re-trained by this script and should not be interpreted as a new-run score.
    "Accuracy": 0.8819753086419753,
    "Macro precision": 0.8045077358563728,
    "Macro recall": 0.8986295912167788,
    "Macro F1": 0.8446085333317856,
}
DISPLAY_WELLS = {
    "磨溪109": "Moxi 109",
    "磨溪110": "Moxi 110",
    "磨溪52": "Moxi 52",
    "高石10": "Gaoshi 10",
    "高石121": "Gaoshi 121",
    "高石123": "Gaoshi 123",
}


def seed_all(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def boundary_target(labels: np.ndarray) -> np.ndarray:
    result = np.zeros(len(labels), dtype=np.float32)
    changes = np.flatnonzero(labels[1:] != labels[:-1])
    result[np.clip(changes, 0, len(labels) - 1)] = 1
    result[np.clip(changes + 1, 0, len(labels) - 1)] = 1
    return result


def bridge_short_internal_gaps(
    prediction: np.ndarray,
    depths: np.ndarray,
    maximum_gap_m: float = MAXIMUM_INTERNAL_GAP_M,
) -> np.ndarray:
    """Join equal reservoir types separated by a very short type-0 gap."""
    connected = np.asarray(prediction, dtype=int).copy()
    depth = np.asarray(depths, dtype=float)
    if len(connected) < 3:
        return connected
    valid_steps = np.diff(depth)
    valid_steps = valid_steps[np.isfinite(valid_steps) & (valid_steps > 0)]
    sample_thickness = float(np.median(valid_steps)) if len(valid_steps) else 0.0
    start = 0
    while start < len(connected):
        if connected[start] != 0:
            start += 1
            continue
        stop = start + 1
        while stop < len(connected) and connected[stop] == 0:
            stop += 1
        gap_thickness = float(depth[stop - 1] - depth[start] + sample_thickness)
        bounded = start > 0 and stop < len(connected)
        if (
            bounded
            and connected[start - 1] > 0
            and connected[start - 1] == connected[stop]
            and gap_thickness <= maximum_gap_m + 1e-9
        ):
            connected[start:stop] = connected[start - 1]
        start = stop
    return connected


def remove_thin_reservoir_segments(
    prediction: np.ndarray,
    depths: np.ndarray,
    minimum_thickness_m: float = MINIMUM_RESERVOIR_THICKNESS_M,
) -> np.ndarray:
    """Bridge short internal gaps, then map sub-threshold segments to type 0."""
    filtered = bridge_short_internal_gaps(prediction, depths)
    depth = np.asarray(depths, dtype=float)
    if len(filtered) == 0:
        return filtered
    valid_steps = np.diff(depth)
    valid_steps = valid_steps[np.isfinite(valid_steps) & (valid_steps > 0)]
    sample_thickness = float(np.median(valid_steps)) if len(valid_steps) else 0.0
    start = 0
    while start < len(filtered):
        label = int(filtered[start])
        stop = start + 1
        while stop < len(filtered) and int(filtered[stop]) == label:
            stop += 1
        if label > 0:
            thickness = float(depth[stop - 1] - depth[start] + sample_thickness)
            if thickness < minimum_thickness_m - 1e-9:
                filtered[start:stop] = 0
        start = stop
    return filtered


def select_features(teacher, columns: list[str]) -> list[str]:
    importance = np.asarray(teacher.feature_importances_)
    selected = [columns[i] for i in np.argsort(importance)[::-1][:FEATURE_COUNT]]
    for feature in RAW_COLUMNS:
        if feature in columns and feature not in selected:
            replacement = next(
                i
                for i in range(len(selected) - 1, -1, -1)
                if selected[i] not in RAW_COLUMNS
            )
            selected[replacement] = feature
    return selected


def prepare_sequences(
    data: pd.DataFrame,
    selected: list[str],
    normalization_wells: set[str],
    teacher,
    teacher_columns: list[str],
) -> tuple[list[dict], dict[str, np.ndarray]]:
    fit = data[data["井名"].isin(normalization_wells)]
    feature_mean = fit[selected].mean().to_numpy(np.float32)
    feature_std = fit[selected].std().replace(0, 1).to_numpy(np.float32)
    raw_mean = fit[RAW_COLUMNS].mean().to_numpy(np.float32)
    raw_std = fit[RAW_COLUMNS].std().replace(0, 1).to_numpy(np.float32)
    sequences = []
    for well, part in data.groupby("井名", sort=True):
        source = part.sort_values("Depth").reset_index(drop=True).copy()
        probability = teacher.predict_proba(source[teacher_columns])
        expanded = np.zeros((len(source), 4), dtype=np.float32)
        expanded[:, teacher.classes_.astype(int)] = probability
        labels = source["类型_约束"].to_numpy(np.int64)
        sequences.append(
            {
                "well": well,
                "source": source,
                "features": (
                    source[selected].to_numpy(np.float32) - feature_mean
                )
                / feature_std,
                "raw": (source[RAW_COLUMNS].to_numpy(np.float32) - raw_mean)
                / raw_std,
                "labels": labels,
                "boundary": boundary_target(labels),
                "teacher": expanded,
            }
        )
    normalization = {
        "feature_mean": feature_mean,
        "feature_std": feature_std,
        "raw_mean": raw_mean,
        "raw_std": raw_std,
    }
    return sequences, normalization


def window_starts(length: int) -> list[int]:
    if length <= WINDOW:
        return [0]
    starts = list(range(0, length - WINDOW + 1, STRIDE))
    last = length - WINDOW
    if starts[-1] != last:
        starts.append(last)
    return starts


class WindowDataset(Dataset):
    def __init__(self, sequences: list[dict]) -> None:
        self.sequences = sequences
        self.index = [
            (row, start)
            for row, item in enumerate(sequences)
            for start in window_starts(len(item["labels"]))
        ]

    def __len__(self) -> int:
        return len(self.index)

    def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
        row, start = self.index[index]
        item = self.sequences[row]
        stop = min(start + WINDOW, len(item["labels"]))
        size = stop - start
        feature_count = item["features"].shape[1]
        features = np.zeros((WINDOW, feature_count), np.float32)
        raw = np.zeros((WINDOW, len(RAW_COLUMNS)), np.float32)
        labels = np.zeros(WINDOW, np.int64)
        boundary = np.zeros(WINDOW, np.float32)
        teacher = np.zeros((WINDOW, 4), np.float32)
        mask = np.zeros(WINDOW, bool)
        features[:size] = item["features"][start:stop]
        raw[:size] = item["raw"][start:stop]
        labels[:size] = item["labels"][start:stop]
        boundary[:size] = item["boundary"][start:stop]
        teacher[:size] = item["teacher"][start:stop]
        mask[:size] = True
        return {
            "features": torch.from_numpy(features),
            "raw": torch.from_numpy(raw),
            "labels": torch.from_numpy(labels),
            "boundary": torch.from_numpy(boundary),
            "teacher": torch.from_numpy(teacher),
            "mask": torch.from_numpy(mask),
        }


class MultiScaleMorphology(nn.Module):
    def __init__(self, width: int) -> None:
        super().__init__()
        branch = width // 3
        self.branches = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Conv1d(
                        len(RAW_COLUMNS),
                        len(RAW_COLUMNS),
                        kernel,
                        padding=kernel // 2,
                        groups=len(RAW_COLUMNS),
                    ),
                    nn.Conv1d(len(RAW_COLUMNS), branch, 1),
                )
                for kernel in (3, 9, 21)
            ]
        )
        self.norm = nn.GroupNorm(8, width)

    def forward(self, raw: torch.Tensor) -> torch.Tensor:
        x = raw.transpose(1, 2)
        x = torch.cat([F.gelu(branch(x)) for branch in self.branches], dim=1)
        return F.gelu(self.norm(x)).transpose(1, 2)


class GeologicalCrossModule(nn.Module):
    """Learn nonlinear geological curve relations without hand-set thresholds."""

    def __init__(self, feature_count: int, width: int) -> None:
        super().__init__()
        self.input = nn.Sequential(
            nn.LayerNorm(feature_count), nn.Linear(feature_count, width), nn.GELU()
        )
        self.cross = nn.ModuleList([nn.Linear(width, width) for _ in range(2)])
        self.norm = nn.ModuleList([nn.LayerNorm(width) for _ in range(2)])
        self.output = nn.Sequential(nn.Linear(width, width), nn.GELU())

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        base = self.input(features)
        state = base
        for linear, norm in zip(self.cross, self.norm):
            state = norm(state + base * torch.tanh(linear(state)))
        return self.output(state)


class LocalGeologyTransformer(nn.Module):
    """Local Transformer with multi-scale morphology and geological interactions."""

    def __init__(self, feature_count: int, width: int = 48) -> None:
        super().__init__()
        self.geology = GeologicalCrossModule(feature_count, width)
        self.morphology = MultiScaleMorphology(width)
        self.fusion_gate = nn.Sequential(nn.Linear(width * 2, width), nn.Sigmoid())
        self.position = nn.Parameter(torch.empty(1, WINDOW, width))
        nn.init.trunc_normal_(self.position, std=0.02)
        layer = nn.TransformerEncoderLayer(
            d_model=width,
            nhead=4,
            dim_feedforward=width * 3,
            dropout=0.08,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(
            layer, num_layers=2, norm=nn.LayerNorm(width)
        )
        self.classifier = nn.Sequential(
            nn.Linear(width, width), nn.GELU(), nn.Dropout(0.08), nn.Linear(width, 4)
        )
        self.reservoir_head = nn.Linear(width, 2)
        self.boundary_head = nn.Linear(width, 1)

    def forward(
        self, features: torch.Tensor, raw: torch.Tensor, mask: torch.Tensor
    ) -> dict[str, torch.Tensor]:
        geology = self.geology(features)
        morphology = self.morphology(raw)
        gate = self.fusion_gate(torch.cat([geology, morphology], dim=-1))
        fused = gate * geology + (1 - gate) * morphology
        state = self.encoder(
            fused + self.position[:, : fused.shape[1]],
            src_key_padding_mask=~mask,
        )
        return {
            "logits": self.classifier(state),
            "reservoir_logits": self.reservoir_head(state),
            "boundary_logits": self.boundary_head(state).squeeze(-1),
            "gate": gate,
        }


def class_weights(sequences: list[dict], device: torch.device) -> torch.Tensor:
    labels = np.concatenate([item["labels"] for item in sequences])
    counts = np.bincount(labels, minlength=4)
    weight = (len(labels) / (4 * counts)) ** 0.50
    return torch.as_tensor(weight / weight.mean(), dtype=torch.float32, device=device)


def loss_function(
    output: dict[str, torch.Tensor],
    batch: dict[str, torch.Tensor],
    weight: torch.Tensor,
) -> tuple[torch.Tensor, dict[str, float]]:
    active = batch["mask"]
    labels = batch["labels"][active]
    logits = output["logits"][active]
    classification = F.cross_entropy(
        logits, labels, weight=weight, label_smoothing=0.01
    )
    reservoir = F.cross_entropy(
        output["reservoir_logits"][active], (labels > 0).long()
    )
    boundary = F.binary_cross_entropy_with_logits(
        output["boundary_logits"][active],
        batch["boundary"][active],
        pos_weight=torch.tensor(3.0, device=labels.device),
    )
    temperature = 2.0
    teacher = batch["teacher"][active].clamp_min(1e-7).pow(1 / temperature)
    teacher = teacher / teacher.sum(-1, keepdim=True)
    distillation = F.kl_div(
        F.log_softmax(logits / temperature, -1),
        teacher,
        reduction="batchmean",
    ) * temperature**2
    loss = classification + 0.10 * reservoir + 0.05 * boundary + 0.15 * distillation
    return loss, {
        "classification": float(classification.detach().cpu()),
        "distillation": float(distillation.detach().cpu()),
        "boundary": float(boundary.detach().cpu()),
    }


@torch.no_grad()
def predict_well(
    model: nn.Module, item: dict, device: torch.device
) -> np.ndarray:
    model.eval()
    length = len(item["labels"])
    total = np.zeros((length, 4), np.float64)
    total_weight = np.zeros(length, np.float64)
    profile = np.hanning(WINDOW + 2)[1:-1]
    profile = 0.25 + 0.75 * profile
    for start in window_starts(length):
        stop = min(start + WINDOW, length)
        size = stop - start
        features = np.zeros((1, WINDOW, item["features"].shape[1]), np.float32)
        raw = np.zeros((1, WINDOW, len(RAW_COLUMNS)), np.float32)
        mask = np.zeros((1, WINDOW), bool)
        features[0, :size] = item["features"][start:stop]
        raw[0, :size] = item["raw"][start:stop]
        mask[0, :size] = True
        output = model(
            torch.as_tensor(features, device=device),
            torch.as_tensor(raw, device=device),
            torch.as_tensor(mask, device=device),
        )
        probability = torch.softmax(output["logits"][0, :size], -1).cpu().numpy()
        weights = profile[:size]
        total[start:stop] += probability * weights[:, None]
        total_weight[start:stop] += weights
    return (total / total_weight[:, None]).astype(np.float32)


def metrics(sequences: list[dict], probabilities: list[np.ndarray]) -> dict[str, float]:
    truth = np.concatenate([item["labels"] for item in sequences])
    prediction = np.concatenate([p.argmax(-1) for p in probabilities])
    precision, recall, f1, _ = precision_recall_fscore_support(
        truth, prediction, labels=LABELS, average="macro", zero_division=0
    )
    return {
        "Accuracy": float(accuracy_score(truth, prediction)),
        "Macro precision": float(precision),
        "Macro recall": float(recall),
        "Macro F1": float(f1),
    }


def metrics_from_predictions(
    sequences: list[dict], predictions: list[np.ndarray]
) -> dict[str, float]:
    truth = np.concatenate([item["labels"] for item in sequences])
    prediction = np.concatenate(predictions)
    precision, recall, f1, _ = precision_recall_fscore_support(
        truth, prediction, labels=LABELS, average="macro", zero_division=0
    )
    return {
        "Accuracy": float(accuracy_score(truth, prediction)),
        "Macro precision": float(precision),
        "Macro recall": float(recall),
        "Macro F1": float(f1),
    }


def select_prior_gate(
    model: nn.Module,
    validation: list[dict],
    device: torch.device,
) -> tuple[float, pd.DataFrame]:
    """Select one soft fusion weight using internal validation wells only."""
    transformer = [predict_well(model, item, device) for item in validation]
    records = []
    best_weight = 0.0
    best_score = -math.inf
    for prior_weight in np.linspace(0, 1, 21):
        fused = [
            (1 - prior_weight) * probability
            + prior_weight * item["teacher"]
            for item, probability in zip(validation, transformer)
        ]
        result = metrics(validation, fused)
        selection = 0.65 * result["Macro F1"] + 0.35 * result["Accuracy"]
        records.append(
            {
                "Prior weight": prior_weight,
                **result,
                "Selection score": selection,
            }
        )
        if selection > best_score:
            best_score = selection
            best_weight = float(prior_weight)
    return best_weight, pd.DataFrame(records)


def train_model(
    training: list[dict],
    validation: list[dict] | None,
    feature_count: int,
    epochs: int,
    device: torch.device,
) -> tuple[nn.Module, pd.DataFrame, int]:
    model = LocalGeologyTransformer(feature_count).to(device)
    loader = DataLoader(
        WindowDataset(training),
        batch_size=24,
        shuffle=True,
        num_workers=0,
        pin_memory=device.type == "cuda",
    )
    weights = class_weights(training, device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=9e-4, weight_decay=2e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=epochs, eta_min=2e-5
    )
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    history = []
    best_score = -math.inf
    best_epoch = epochs
    best_state = None
    wait = 0
    for epoch in range(1, epochs + 1):
        model.train()
        totals: dict[str, float] = {}
        count = 0
        for batch in loader:
            batch = {key: value.to(device, non_blocking=True) for key, value in batch.items()}
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                output = model(batch["features"], batch["raw"], batch["mask"])
                loss, parts = loss_function(output, batch, weights)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 2.0)
            scaler.step(optimizer)
            scaler.update()
            totals["Training loss"] = totals.get("Training loss", 0) + float(loss.detach())
            for key, value in parts.items():
                totals[key] = totals.get(key, 0) + value
            count += 1
        scheduler.step()
        row = {"Epoch": epoch, **{key: value / count for key, value in totals.items()}}
        if validation:
            validation_metrics = metrics(
                validation, [predict_well(model, item, device) for item in validation]
            )
            row.update({f"Validation {key}": value for key, value in validation_metrics.items()})
            score = 0.65 * validation_metrics["Macro F1"] + 0.35 * validation_metrics["Accuracy"]
            if score > best_score:
                best_score = score
                best_epoch = epoch
                best_state = deepcopy(model.state_dict())
                wait = 0
            else:
                wait += 1
        history.append(row)
        if validation and wait >= PATIENCE:
            break
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, pd.DataFrame(history), best_epoch


def save_figures(
    history: pd.DataFrame,
    comparison: pd.DataFrame,
    truth: np.ndarray,
    prediction: np.ndarray,
) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(8.6, 3.4))
    axes[0].plot(history["Epoch"], history["Training loss"], color="#315F84")
    axes[0].set(xlabel="Epoch", ylabel="Loss", title="Training loss")
    if "Validation Macro F1" in history:
        axes[1].plot(history["Epoch"], history["Validation Macro F1"], color="#B45F06")
        axes[1].plot(history["Epoch"], history["Validation Accuracy"], color="#4F812D")
        axes[1].legend(["Macro F1", "Accuracy"], frameon=False)
    axes[1].set(xlabel="Epoch", ylabel="Score", ylim=(0, 1), title="Internal validation")
    for axis in axes:
        axis.grid(color="#E4E4E4", linewidth=0.6)
    fig.tight_layout()
    save_all(fig, OUT / "Fig01_training_validation")

    fig, axis = plt.subplots(figsize=(6.8, 3.8))
    measures = ["Accuracy", "Macro precision", "Macro recall", "Macro F1"]
    x = np.arange(len(comparison))
    width = 0.19
    colors = ["#9ECAE1", "#FDD0A2", "#BFD3A6", "#C7B0D5"]
    for i, (measure, color) in enumerate(zip(measures, colors)):
        axis.bar(x + (i - 1.5) * width, comparison[measure], width, label=measure, color=color)
    axis.set_xticks(x, comparison["Model"])
    axis.set_ylim(0, 1.05)
    axis.set_ylabel("Score")
    axis.legend(frameon=False, ncol=2)
    axis.grid(axis="y", color="#E4E4E4", linewidth=0.6)
    fig.tight_layout()
    save_all(fig, OUT / "Fig02_baseline_comparison")

    matrix = confusion_matrix(truth, prediction, labels=LABELS, normalize="true")
    fig, axis = plt.subplots(figsize=(4.3, 3.9))
    image = axis.imshow(matrix, cmap="Blues", vmin=0, vmax=1)
    for row in range(4):
        for column in range(4):
            axis.text(
                column,
                row,
                f"{matrix[row, column]:.2f}",
                ha="center",
                va="center",
                color="white" if matrix[row, column] > 0.55 else "#222222",
            )
    axis.set(
        xticks=LABELS,
        yticks=LABELS,
        xticklabels=[f"Type {x}" for x in LABELS],
        yticklabels=[f"Type {x}" for x in LABELS],
        xlabel="Predicted type",
        ylabel="Observed type",
        title="Local Geology Transformer",
    )
    fig.colorbar(image, ax=axis, fraction=0.045, pad=0.04)
    fig.tight_layout()
    save_all(fig, OUT / "Fig03_confusion_matrix")


def main(data_dir: Path, layer_file: Path, output_dir: Path) -> None:
    global OUT
    OUT = output_dir.resolve()
    warnings.filterwarnings("ignore", category=PerformanceWarning)
    seed_all()
    OUT.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    raw = load_curve_csvs(data_dir, require_label=True)
    available_wells = set(raw["井名"])
    if len(available_wells) != 19:
        raise ValueError(f"The published split requires 19 wells; found {len(available_wells)}")
    expected_wells = FIXED_TEST_WELLS | VALIDATION_WELLS
    if not expected_wells <= available_wells:
        raise ValueError(f"Required split wells are missing: {sorted(expected_wells - available_wells)}")
    intervals = read_layer_intervals(layer_file, available_wells)
    data, feature_columns = build_features(raw, intervals)
    # This preserves the established label definition; it is not an inference rule.
    data["类型_约束"] = data["类型"].astype(int).where(data["DEN"] < 2.9, 0)
    official_train = set(data["井名"].unique()) - FIXED_TEST_WELLS
    tuning_train = official_train - VALIDATION_WELLS

    tuning_teacher = make_model()
    tuning_mask = data["井名"].isin(tuning_train)
    tuning_teacher.fit(
        data.loc[tuning_mask, feature_columns],
        data.loc[tuning_mask, "类型_约束"],
        sample_weight=sample_weight(data.loc[tuning_mask, "类型_约束"]),
    )
    tuning_features = select_features(tuning_teacher, feature_columns)
    tuning_sequences, _ = prepare_sequences(
        data, tuning_features, tuning_train, tuning_teacher, feature_columns
    )
    fit_sequences = [item for item in tuning_sequences if item["well"] in tuning_train]
    validation_sequences = [
        item for item in tuning_sequences if item["well"] in VALIDATION_WELLS
    ]
    tuning_model, validation_history, best_epoch = train_model(
        fit_sequences,
        validation_sequences,
        len(tuning_features),
        MAX_EPOCHS,
        device,
    )
    validation_history.to_csv(
        OUT / "internal_validation_history.csv", index=False, encoding="utf-8-sig"
    )
    prior_weight, gate_search = select_prior_gate(
        tuning_model, validation_sequences, device
    )
    gate_search.to_csv(
        OUT / "internal_validation_prior_gate.csv",
        index=False,
        encoding="utf-8-sig",
    )

    final_teacher = make_model()
    final_mask = data["井名"].isin(official_train)
    final_teacher.fit(
        data.loc[final_mask, feature_columns],
        data.loc[final_mask, "类型_约束"],
        sample_weight=sample_weight(data.loc[final_mask, "类型_约束"]),
    )
    final_features = select_features(final_teacher, feature_columns)
    sequences, normalization = prepare_sequences(
        data, final_features, official_train, final_teacher, feature_columns
    )
    training = [item for item in sequences if item["well"] in official_train]
    testing = [item for item in sequences if item["well"] in FIXED_TEST_WELLS]
    final_epochs = max(40, min(MAX_EPOCHS, round(best_epoch * 1.15)))
    seed_all()
    model, final_history, _ = train_model(
        training, None, len(final_features), final_epochs, device
    )
    final_history.to_csv(
        OUT / "final_training_history.csv", index=False, encoding="utf-8-sig"
    )

    transformer_probabilities = [
        predict_well(model, item, device) for item in testing
    ]
    probabilities = [
        (1 - prior_weight) * probability + prior_weight * item["teacher"]
        for item, probability in zip(testing, transformer_probabilities)
    ]
    filtered_predictions = [
        remove_thin_reservoir_segments(
            probability.argmax(-1), item["source"]["Depth"].to_numpy(float)
        )
        for item, probability in zip(testing, probabilities)
    ]
    truth = np.concatenate([item["labels"] for item in testing])
    prediction = np.concatenate(filtered_predictions)
    score = metrics_from_predictions(testing, filtered_predictions)
    transformer_score = metrics(testing, transformer_probabilities)
    comparison = pd.DataFrame(
        [
            {"Model": "Transformer baseline (historical reference)", **BASELINE},
            {"Model": "Local Geo-Transformer", **transformer_score},
            {"Model": "Prior-guided Geo-Transformer", **score},
        ]
    )
    comparison.to_csv(OUT / "metrics_comparison.csv", index=False, encoding="utf-8-sig")
    report = classification_report(
        truth,
        prediction,
        labels=LABELS,
        target_names=[f"Type {label}" for label in LABELS],
        output_dict=True,
        zero_division=0,
    )
    (OUT / "classification_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    pd.DataFrame(
        confusion_matrix(truth, prediction, labels=LABELS),
        index=[f"Observed_{label}" for label in LABELS],
        columns=[f"Predicted_{label}" for label in LABELS],
    ).to_csv(OUT / "confusion_matrix.csv", encoding="utf-8-sig")

    frames = []
    for item, probability, item_prediction in zip(
        testing, probabilities, filtered_predictions
    ):
        result = item["source"][
            ["井名", "Depth", "AC", "CNL", "DEN", "GR", "RT", "RXO", "类型", "类型_约束"]
        ].copy()
        result["预测类型_厚度过滤前"] = probability.argmax(-1)
        result["预测类型_先验引导地质Transformer"] = item_prediction
        for label in LABELS:
            result[f"类型{label}概率"] = probability[:, label]
        frames.append(result)
        plot_source = item["source"].copy()
        plot_source["类型"] = plot_source["类型_约束"]
        curve_panels_v3(
            plot_source,
            item_prediction,
            OUT
            / f"Fig04_prediction_{DISPLAY_WELLS.get(item['well'], item['well']).replace(' ', '_')}",
            (
                "Prior-Guided Local Geology Transformer: "
                f"{DISPLAY_WELLS.get(item['well'], item['well'])}"
            ),
        )
    pd.concat(frames, ignore_index=True).to_csv(
        OUT / "test_predictions.csv", index=False, encoding="utf-8-sig"
    )
    torch.save(
        {
            "state_dict": model.state_dict(),
            "feature_columns": final_features,
            "teacher_feature_columns": feature_columns,
            **normalization,
            "raw_columns": RAW_COLUMNS,
            "window": WINDOW,
            "stride": STRIDE,
            "validation_best_epoch": best_epoch,
            "final_epochs": final_epochs,
            "prior_weight": prior_weight,
            "minimum_reservoir_thickness_m": MINIMUM_RESERVOIR_THICKNESS_M,
            "maximum_internal_gap_m": MAXIMUM_INTERNAL_GAP_M,
            "metrics": score,
            "inference": (
                "Transformer plus validation-calibrated unconstrained GBDT "
                "soft-prior gate, 0.25 m internal-gap connection, and 1.0 m "
                "minimum-thickness filter"
            ),
        },
        OUT / "local_geology_transformer.pt",
    )
    joblib.dump(final_teacher, OUT / "unconstrained_gbdt_prior.joblib")
    save_figures(validation_history, comparison, truth, prediction)
    summary = {
        "historical_transformer_baseline": BASELINE,
        "local_geology_transformer": transformer_score,
        "prior_guided_geo_transformer": score,
        "accuracy_target_reached": score["Accuracy"] >= 0.90,
        "validation_best_epoch": best_epoch,
        "final_epochs": final_epochs,
        "prior_weight_selected_on_internal_validation": prior_weight,
        "minimum_reservoir_thickness_m": MINIMUM_RESERVOIR_THICKNESS_M,
        "maximum_internal_gap_m": MAXIMUM_INTERNAL_GAP_M,
        "train_wells": sorted(official_train),
        "validation_wells": sorted(VALIDATION_WELLS),
        "test_wells": sorted(FIXED_TEST_WELLS),
        "test_used_for_selection": False,
        "architecture": (
            "overlapping local-window Transformer + multi-scale curve morphology "
            "+ learnable geological cross module + reservoir/boundary auxiliaries"
        ),
        "constraint": (
            "no curve-value threshold or class-forcing rule; equal reservoir "
            "types across gaps <=0.25 m are connected before type 1-3 segments "
            "thinner than 1.0 m are mapped to type 0"
        ),
        "prior_module": (
            "unconstrained GBDT soft probability prior; its fusion weight is "
            "selected only on the two internal validation wells"
        ),
        "device": str(device),
    }
    (OUT / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train and evaluate GeoMPF-Transformer")
    parser.add_argument("--data-dir", required=True, type=Path,
                        help="Directory containing labeled one-well-per-file CSVs")
    parser.add_argument("--layer-file", required=True, type=Path,
                        help="GB18030 tab-separated Jia2-2 layer interval file")
    parser.add_argument("--output-dir", type=Path, default=OUT)
    args = parser.parse_args()
    main(args.data_dir, args.layer_file, args.output_dir)
