"""Well-track plotting helpers extracted from the completed experiment."""

from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import BoundaryNorm, ListedColormap
from matplotlib.patches import Patch

from teacher import LABELS

TYPE_COLORS = ["#9BC6E3", "#F9E394", "#F2A7A3", "#CDB0D1"]
mpl.rcParams.update({"pdf.fonttype": 42, "svg.fonttype": "none"})


def save_all(fig: plt.Figure, stem: Path) -> None:
    for extension in ("png", "pdf", "svg"):
        fig.savefig(stem.with_suffix(f".{extension}"), dpi=600, bbox_inches="tight")
    plt.close(fig)


def depth_edges(depth: np.ndarray) -> np.ndarray:
    if len(depth) == 1:
        return np.array([depth[0] - 0.05, depth[0] + 0.05])
    middle = (depth[:-1] + depth[1:]) / 2.0
    return np.r_[depth[0] - (middle[0] - depth[0]), middle,
                 depth[-1] + (depth[-1] - middle[-1])]


def exact_class_track(axis: plt.Axes, depth: np.ndarray,
                      labels: np.ndarray, title: str) -> None:
    cmap = ListedColormap(TYPE_COLORS)
    norm = BoundaryNorm(np.arange(-0.5, 4.5, 1.0), cmap.N)
    axis.pcolormesh(np.array([0.35, 0.65]), depth_edges(depth), labels[:, None],
                    cmap=cmap, norm=norm, shading="flat")
    axis.set_title(title, fontsize=9, pad=6)
    axis.set_xlim(0, 1)
    axis.set_xticks([])
    axis.grid(axis="y", color="#E6E6E6", linewidth=0.55)


def curve_panels_v3(frame: pd.DataFrame, prediction: np.ndarray,
                    file_stem: Path, title: str) -> None:
    depth = frame["Depth"].to_numpy(float)
    fig, axes = plt.subplots(1, 5, figsize=(10.4, 7.8), sharey=True,
                             gridspec_kw={"width_ratios": [1.25, 1.25, 1.25, 0.55, 0.55]})
    left, right = axes[0], axes[0].twiny()
    left.plot(frame["GR"], depth, color="#AA86B0", linewidth=1.1)
    right.plot(frame["CNL"], depth, color="#E0BC33", linewidth=1.1)
    left.set_xlim(1, 100)
    right.set_xlim(-5, 25)
    left.set_xlabel("GR", color="#AA86B0", labelpad=3)
    right.set_xlabel("CNL", color="#C89E1B", labelpad=3)
    left.xaxis.set_label_position("top")
    right.xaxis.set_label_position("top")
    left.xaxis.tick_top()
    right.xaxis.tick_top()
    right.spines["top"].set_position(("axes", 1.11))
    left.tick_params(axis="x", colors="#AA86B0", pad=1)
    right.tick_params(axis="x", colors="#C89E1B", pad=1)
    left.set_ylabel("Depth (m)")

    left, right = axes[1], axes[1].twiny()
    left.plot(frame["DEN"], depth, color="#E98784", linewidth=1.1)
    right.plot(frame["AC"], depth, color="#6FAFD6", linewidth=1.1)
    left.set_xlim(2.5, 3.0)
    right.set_xlim(80, 40)
    left.set_xlabel("DEN", color="#E98784", labelpad=3)
    right.set_xlabel("AC", color="#6FAFD6", labelpad=3)
    left.xaxis.set_label_position("top")
    right.xaxis.set_label_position("top")
    left.xaxis.tick_top()
    right.xaxis.tick_top()
    right.spines["top"].set_position(("axes", 1.11))
    left.tick_params(axis="x", colors="#E98784", pad=1)
    right.tick_params(axis="x", colors="#6FAFD6", pad=1)

    left, right = axes[2], axes[2].twiny()
    left.semilogx(frame["RT"].clip(lower=1), depth,
                  color="#A88624", linewidth=1.05)
    right.semilogx(frame["RXO"].clip(lower=1), depth,
                   color="#25A8B7", linewidth=1.05)
    left.set_xlim(1, 100000)
    right.set_xlim(1, 100000)
    left.set_xlabel("RT", color="#A88624", labelpad=3)
    right.set_xlabel("RXO", color="#25A8B7", labelpad=3)
    left.xaxis.set_label_position("top")
    right.xaxis.set_label_position("top")
    left.xaxis.tick_top()
    right.xaxis.tick_top()
    right.spines["top"].set_position(("axes", 1.11))
    left.tick_params(axis="x", colors="#A88624", pad=1)
    right.tick_params(axis="x", colors="#25A8B7", pad=1)

    exact_class_track(axes[3], depth, frame["类型"].to_numpy(int), "Observed")
    exact_class_track(axes[4], depth, prediction, "Predicted")
    for axis in axes[:3]:
        axis.grid(color="#E6E6E6", linewidth=0.55)
    axes[0].invert_yaxis()
    fig.suptitle(title, y=0.985, fontsize=11)
    fig.legend([Patch(color=color) for color in TYPE_COLORS],
               [f"Type {i}" for i in LABELS], ncol=4, frameon=False,
               loc="lower center", bbox_to_anchor=(0.5, -0.005), fontsize=8)
    fig.subplots_adjust(wspace=0.30, top=0.79, bottom=0.08)
    save_all(fig, file_stem)
