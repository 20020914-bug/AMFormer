# Local release check

This folder is a standalone code-only package for the final GeoMPF-Transformer experiment. It was created from the completed `train_local_geology_transformer.py`, with the GBDT teacher and plotting helpers separated from older experiments. The published method's network, loss coefficients, optimizer, validation selection, probability fusion and sequence constraint remain in `train.py`.

## Checks performed

- `python -m compileall -q GeoMPF-Transformer-public`: passed.
- `python train.py --help` and `python predict.py --help`: passed.
- A prediction smoke run used the already fitted checkpoint and matching GBDT prior on independent test well 高石10. Compared with the retained final `test_predictions.csv`: 304/304 depth points aligned, 304/304 final classes agreed, and the largest absolute discrepancy in any of the four fused class probability columns was **0.0**.
- The original input labels were not used by `predict.py`; its output was generated from the six curves and the supplied layer interval.
- Scanned repository text/code for local absolute paths and common credential terms: no private machine paths or credentials found.
- The package contains source and documentation only. It contains no raw logs, real layer table, fitted weights, original predictions, or experiment charts. `.gitignore` blocks common generated and data files.
- The test environment had Python 3.11.5, PyTorch 2.3.1+cu121, NumPy 1.26.4, pandas 2.2.3, scikit-learn 1.6.1, Matplotlib 3.10.1, and joblib 1.4.2.

## Scope of verification

The final 19-well training experiment was **not rerun** when organizing this repository, so the historical metrics in README are from the retained completed run. The single-well inference comparison verifies exact behavior for that checkpoint and well; it does not independently verify the entire training runtime or cross-machine bitwise reproducibility.

Before a public upload, the repository owner should choose an open-source license and confirm rights to distribute any data or trained weights they may later add. This release package does not include them.
