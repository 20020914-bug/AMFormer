"""Shared, label-safe feature engineering for 嘉二2 reservoir identification."""

from __future__ import annotations

import csv
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd


CURVE_COLUMNS = ["AC", "CNL", "DEN", "GR", "RT", "RXO"]
BASE_FEATURES = ["AC", "CNL", "DEN", "GR", "log_RT", "log_RXO", "log_RT_minus_log_RXO"]
WINDOW_SAMPLES = {"0p5m": 5, "1m": 9, "2m": 17}
CORRELATION_COLUMNS = ["AC", "CNL", "DEN", "GR", "log_RT", "log_RXO"]
TARGET_LAYER = "嘉二2"


def read_layer_intervals(layer_file: Path, wells: set[str]) -> dict[str, tuple[float, float]]:
    """Read only the requested wells, so unrelated duplicate records do not affect training."""
    with layer_file.open("r", encoding="gb18030", newline="") as handle:
        rows = list(csv.reader(handle, delimiter="\t"))
    header = rows[0]
    well_idx = header.index("井名")
    name_idx = header.index("地层名称")
    top_idx = header.index("顶深(米)")
    base_idx = header.index("底深(米)")

    results: dict[str, list[tuple[float, float]]] = {well: [] for well in wells}
    for row in rows[1:]:
        if row[well_idx] in wells and row[name_idx].strip() == TARGET_LAYER:
            results[row[well_idx]].append((float(row[top_idx]), float(row[base_idx])))

    missing = sorted(well for well, intervals in results.items() if not intervals)
    duplicate = {well: intervals for well, intervals in results.items() if len(intervals) > 1}
    if missing:
        raise ValueError(f"缺少嘉二2分层记录: {missing}")
    if duplicate:
        raise ValueError(f"嘉二2分层记录不唯一，无法确定层段: {duplicate}")
    return {well: intervals[0] for well, intervals in results.items()}


def load_curve_csvs(data_dir: Path, require_label: bool) -> pd.DataFrame:
    files = sorted(data_dir.glob("*.csv"))
    if not files:
        raise FileNotFoundError(f"未找到CSV文件: {data_dir}")
    required = {"井名", "Depth", *CURVE_COLUMNS}
    if require_label:
        required.add("类型")

    frames = []
    for file in files:
        try:
            frame = pd.read_csv(file, encoding="utf-8-sig")
        except UnicodeDecodeError:
            # Accept a user-supplied GB18030 CSV without changing its original encoding.
            frame = pd.read_csv(file, encoding="gb18030")
        missing = required - set(frame.columns)
        if missing:
            raise ValueError(f"{file.name} 缺少列: {sorted(missing)}")
        if frame["井名"].nunique() != 1 or frame["井名"].iat[0] != file.stem:
            raise ValueError(f"{file.name} 的井名列应与文件名一致")
        frames.append(frame)

    combined = pd.concat(frames, ignore_index=True)
    numeric_columns = ["Depth", *CURVE_COLUMNS]
    if "类型" in combined.columns:
        numeric_columns.append("类型")
    for column in numeric_columns:
        combined[column] = pd.to_numeric(combined[column], errors="raise")
    if require_label and not combined["类型"].isin([0, 1, 2, 3]).all():
        raise ValueError("类型列只能包含0、1、2、3")
    return combined


def _clean_curve(values: pd.Series, well: str, curve: str) -> pd.Series:
    clean = values.replace(-9999, np.nan).astype(float)
    if clean.isna().all():
        raise ValueError(f"{well} 的 {curve} 全为缺失值")
    return clean.interpolate(limit_direction="both").bfill().ffill()


def build_features(
    data: pd.DataFrame,
    layer_intervals: dict[str, tuple[float, float]],
    include_salt_attention: bool = True,
    include_deep_gr_attention: bool = True,
    include_error_guided_features: bool = True,
) -> tuple[pd.DataFrame, list[str]]:
    """Create curve and confirmed geological features without using label-derived intervals."""
    blocks = []
    for well, source in data.groupby("井名", sort=True):
        frame = source.sort_values("Depth").reset_index(drop=True).copy()
        top, base = layer_intervals[well]
        thickness = base - top
        if thickness <= 0:
            raise ValueError(f"{well} 的嘉二2厚度必须大于0")
        if not frame["Depth"].between(top - 1e-8, base + 1e-8).all():
            raise ValueError(f"{well} 存在嘉二2层段外的采样点")

        for curve in CURVE_COLUMNS:
            frame[curve] = _clean_curve(frame[curve], well, curve)
        frame["log_RT"] = np.log1p(frame["RT"].clip(lower=0))
        frame["log_RXO"] = np.log1p(frame["RXO"].clip(lower=0))
        frame["log_RT_minus_log_RXO"] = frame["log_RT"] - frame["log_RXO"]
        if include_salt_attention:
            frame["salt_flag_DEN_ge_2p9"] = (frame["DEN"] >= 2.9).astype(float)

        # Confirmed geological feature: normalized position from 嘉二2 top (0) to base (1).
        frame["jiaer2_relative_position"] = ((frame["Depth"] - top) / thickness).clip(0, 1)

        for feature in BASE_FEATURES:
            for window_name, samples in WINDOW_SAMPLES.items():
                rolling = frame[feature].rolling(samples, center=True, min_periods=1)
                frame[f"{feature}_mean_{window_name}"] = rolling.mean()
                frame[f"{feature}_std_{window_name}"] = rolling.std(ddof=0).fillna(0)

        if include_deep_gr_attention:
            # Soft evidence for the user's observation: high GR in the lower part of the target interval is less reservoir-like.
            frame["GR_within_well_rank"] = frame["GR"].rank(pct=True)
            frame["GR_deep_high_score"] = frame["GR_within_well_rank"] * frame["jiaer2_relative_position"]
            gr_local_excess = (frame["GR"] - frame["GR_mean_2m"]) / (frame["GR_std_2m"] + 1e-6)
            frame["GR_deep_high_local_excess"] = frame["jiaer2_relative_position"] * gr_local_excess.clip(lower=0)

        if include_error_guided_features:
            # Error-guided soft sequence descriptors: distinguish the first and repeated lower-interval GR-high events.
            lower_interval = frame["jiaer2_relative_position"] >= 0.5
            gr_high = frame["GR"] >= frame["GR"].quantile(0.75)
            lower_gr_high = lower_interval & gr_high
            event_start = lower_gr_high & ~lower_gr_high.shift(1, fill_value=False)
            event_order = event_start.cumsum().to_numpy(dtype=float)
            frame["GR_lower_high_event_order"] = np.where(lower_gr_high, np.minimum(event_order, 3.0), 0.0)
            frame["GR_lower_first_high_event"] = (frame["GR_lower_high_event_order"] == 1.0).astype(float)
            frame["GR_lower_repeated_high_event"] = (frame["GR_lower_high_event_order"] >= 2.0).astype(float)

            # AC rise relative to its preceding local minimum preserves weak but sustained upward changes.
            previous_ac_min = frame["AC"].shift(1).rolling(WINDOW_SAMPLES["1m"], min_periods=1).min().fillna(frame["AC"])
            frame["AC_rise_from_previous_min_1m"] = (frame["AC"] - previous_ac_min).clip(lower=0)
            frame["AC_rise_relative_to_local_variation_1m"] = (
                frame["AC_rise_from_previous_min_1m"] / (frame["AC_std_1m"] + 1e-6)
            ).clip(upper=5.0)

            # Type-2 support should weaken smoothly where density is locally almost unchanged.
            frame["DEN_relative_variation_1m"] = frame["DEN_std_1m"] / (frame["DEN_mean_1m"].abs() + 1e-6)
            frame["DEN_low_variation_score_1m"] = 1.0 - frame["DEN_std_1m"].rank(pct=True)

        if include_salt_attention:
            # Attention features supplied by the interpreter: high-DEN gypsum/salt and GR stability.
            for window_name, samples in WINDOW_SAMPLES.items():
                frame[f"below_salt_{window_name}"] = (
                    frame["salt_flag_DEN_ge_2p9"].shift(1).rolling(samples, min_periods=1).max().fillna(0)
                )
                gr_rolling = frame["GR"].rolling(samples, center=True, min_periods=1)
                frame[f"GR_range_{window_name}"] = gr_rolling.max() - gr_rolling.min()
                frame[f"GR_mean_abs_change_{window_name}"] = frame["GR"].diff().abs().rolling(
                    samples, center=True, min_periods=1
                ).mean().bfill().ffill()

        depth = frame["Depth"].to_numpy(dtype=float)
        for feature in BASE_FEATURES:
            values = frame[feature].to_numpy(dtype=float)
            gradient = np.gradient(values, depth) if len(frame) > 1 else np.zeros(len(frame))
            frame[f"{feature}_gradient"] = gradient
            frame[f"{feature}_curvature"] = np.gradient(gradient, depth) if len(frame) > 2 else 0.0

        # Shape-only representations: ranks and directions retain changes but discard absolute curve levels.
        for curve in CORRELATION_COLUMNS:
            for window_name in WINDOW_SAMPLES:
                frame[f"{curve}_std_rank_{window_name}"] = frame[f"{curve}_std_{window_name}"].rank(pct=True)
            frame[f"{curve}_gradient_abs_rank"] = frame[f"{curve}_gradient"].abs().rank(pct=True)
            frame[f"{curve}_gradient_direction"] = np.sign(frame[f"{curve}_gradient"])
            frame[f"{curve}_curvature_abs_rank"] = frame[f"{curve}_curvature"].abs().rank(pct=True)
            frame[f"{curve}_curvature_direction"] = np.sign(frame[f"{curve}_curvature"])

        change_count_1m = sum((frame[f"{curve}_std_rank_1m"] >= 0.65).astype(int) for curve in CORRELATION_COLUMNS)
        change_count_2m = sum((frame[f"{curve}_std_rank_2m"] >= 0.65).astype(int) for curve in CORRELATION_COLUMNS)
        frame["shape_change_count_1m"] = change_count_1m
        frame["shape_change_count_2m"] = change_count_2m
        frame["shape_change_gate"] = ((change_count_1m >= 2) | (change_count_2m >= 2)).astype(int)

        # These local correlations describe curve shape; the model does not assume a fixed direction.
        for first, second in combinations(CORRELATION_COLUMNS, 2):
            frame[f"corr_1m_{first}_{second}"] = frame[first].rolling(
                WINDOW_SAMPLES["1m"], center=True, min_periods=3
            ).corr(frame[second]).fillna(0)
        blocks.append(frame)

    feature_data = pd.concat(blocks, ignore_index=True)
    feature_columns = [
        *BASE_FEATURES,
        "jiaer2_relative_position",
        *(["salt_flag_DEN_ge_2p9"] if include_salt_attention else []),
        *[
            f"{feature}_{stat}_{window_name}"
            for feature in BASE_FEATURES
            for window_name in WINDOW_SAMPLES
            for stat in ("mean", "std")
        ],
        *(["GR_within_well_rank", "GR_deep_high_score", "GR_deep_high_local_excess"] if include_deep_gr_attention else []),
        *(
            [
                "GR_lower_high_event_order",
                "GR_lower_first_high_event",
                "GR_lower_repeated_high_event",
                "AC_rise_from_previous_min_1m",
                "AC_rise_relative_to_local_variation_1m",
                "DEN_relative_variation_1m",
                "DEN_low_variation_score_1m",
            ]
            if include_error_guided_features
            else []
        ),
        *[f"{feature}_gradient" for feature in BASE_FEATURES],
        *[f"{feature}_curvature" for feature in BASE_FEATURES],
        *[f"corr_1m_{first}_{second}" for first, second in combinations(CORRELATION_COLUMNS, 2)],
        *([f"below_salt_{window_name}" for window_name in WINDOW_SAMPLES] if include_salt_attention else []),
        *([f"GR_range_{window_name}" for window_name in WINDOW_SAMPLES] if include_salt_attention else []),
        *([f"GR_mean_abs_change_{window_name}" for window_name in WINDOW_SAMPLES] if include_salt_attention else []),
        *[f"{curve}_std_rank_{window_name}" for curve in CORRELATION_COLUMNS for window_name in WINDOW_SAMPLES],
        *[f"{curve}_gradient_abs_rank" for curve in CORRELATION_COLUMNS],
        *[f"{curve}_gradient_direction" for curve in CORRELATION_COLUMNS],
        *[f"{curve}_curvature_abs_rank" for curve in CORRELATION_COLUMNS],
        *[f"{curve}_curvature_direction" for curve in CORRELATION_COLUMNS],
        "shape_change_count_1m",
        "shape_change_count_2m",
        "shape_change_gate",
    ]
    if feature_data[feature_columns].isna().any().any():
        raise ValueError("特征工程后仍有缺失值")
    return feature_data, feature_columns
