# Input data format

Training expects **one CSV per well** in the directory passed to `--data-dir`. Prediction uses the same file format without the `类型` column. The filename stem must equal the value in `井名` throughout that file. CSV files may be UTF-8 with BOM or GB18030.

Required columns:

| Column | Meaning |
|---|---|
| `井名` | Well identifier; must match filename stem |
| `Depth` | Depth in metres; strictly increasing after sorting |
| `AC`, `CNL`, `DEN`, `GR`, `RT`, `RXO` | Six numeric logging curves; preserve the original training units |
| `类型` | Training label, integer 0, 1, 2 or 3; omit for prediction |

The training code constructs `log_RT = log1p(max(RT, 0))` and `log_RXO = log1p(max(RXO, 0))`, plus engineered geological features. It maps labeled rows with `DEN >= 2.9` to Type 0 **only when constructing the training/evaluation target**. The inference path contains no density based label override. Ensure that the curve units and normalization context match the training data before using a fitted model.

Layer intervals use a **GB18030 encoded tab separated text file** with the exact columns `井名`, `地层名称`, `顶深(米)`, `底深(米)`. Each input well must have exactly one `嘉二2` row, and its CSV depth samples must lie within that interval. These intervals are used to compute relative position within the target layer. Example of the *layout* (illustrative values only):

```text
井名<TAB>地层名称<TAB>顶深(米)<TAB>底深(米)
ExampleWell<TAB>嘉二2<TAB>3000<TAB>3040
```

The demonstration text above is a schema illustration, not research data. Neither the 19 well logs nor their layer intervals are included in this repository. The exact original split identifiers are in `teacher.py` and `train.py`; the published experiment requires those well IDs to reproduce its split.
